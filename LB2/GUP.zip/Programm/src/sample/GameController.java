package sample;

import javafx.animation.*;
import javafx.beans.InvalidationListener;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.*;
import javafx.scene.canvas.*;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;


import java.net.URL;
import java.util.ResourceBundle;

public class GameController implements Initializable {

    @FXML
    private Canvas canvas;

    @FXML
    public Label highscore;

    static double pmx = 424;
    static double pmy = 728;

    public double score = 0;

    StringProperty scores = new StringProperty() {
        @Override
        public void bind(ObservableValue<? extends String> observableValue) {

        }

        @Override
        public void unbind() {

        }

        @Override
        public boolean isBound() {
            return false;
        }

        @Override
        public Object getBean() {
            return null;
        }

        @Override
        public String getName() {
            return null;
        }

        @Override
        public String get() {
            return null;
        }

        @Override
        public void addListener(ChangeListener<? super String> changeListener) {

        }

        @Override
        public void removeListener(ChangeListener<? super String> changeListener) {

        }

        @Override
        public void addListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void removeListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void set(String s) {

        }
    };



    public static WallsModel walls;
    public static PacDotsModel pacDotsModel;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        PacManController pacman = new PacManController();


        walls = new WallsModel();
        pacDotsModel = new PacDotsModel();


        canvas.setFocusTraversable(true);

        Image pmm = new Image("/sample/img/Pac-Man_Maze_tr.png", canvas.getWidth(), canvas.getHeight(), true, true);
        Image pm = new Image("/sample/img/Pac-Man.gif", 55, 55, true, true);
        Image blinky = new Image("sample/img/Blinky.gif", 40, 40, true, true);


        ImageView pmmview = new ImageView(pmm);
        SnapshotParameters params = new SnapshotParameters();
        params.setFill(Color.TRANSPARENT);

        Image pmmf = pmmview.snapshot(params, null);
        Rectangle pacdot;

        for (int y = 0; y < 12; y++) {
            pacDotsModel.setPdx(46);
            for (int i = 0; i < 30; i++) {


                pacdot = new Rectangle(pacDotsModel.getPdx(), pacDotsModel.getPdy(), 7, 7);
                if (pacwall(pacdot)) {
                    pacDotsModel.pacdots.add(pacdot);
                }
                pacDotsModel.setPdx(pacDotsModel.getPdx() + 28);
            }
            pacDotsModel.setPdy(pacDotsModel.getPdy() + 73.9);
        }








        for (Rectangle pdot : pacDotsModel.pacdots) {
            gc.setFill(Color.GREENYELLOW);
            gc.fillRect(pdot.getX(), pdot.getY(), pdot.getWidth(), pdot.getHeight());

        }

        scores.setValue(Double.toString(score));
        highscore.textProperty().bind(scores);



        AnimationTimer animationTimer = new AnimationTimer() {

            @Override
            public void handle(long now) {
                gc.drawImage(pmmf, 0, 0);
                BlinkyController bc = new BlinkyController();
                bc.blinkycontrol(canvas, gc, blinky);
                if (pacman.eatdot(pm)) {

                    score += 10;
                }


                for (Rectangle wall : walls.walls
                ) {
                    gc.strokeRect(wall.getX(), wall.getY(), wall.getWidth(), wall.getHeight());
                }

                PacManController pc = new PacManController();
                pc.pacman(canvas, gc, pm);
                System.out.println(score);
                /*System.out.println(canvas.getWidth());
                System.out.println(canvas.getHeight());
                System.out.println(canvas.getLayoutX());
                System.out.println(canvas.getLayoutY());*/
            }


        };
        animationTimer.start();


    }

    public boolean pacwall(Rectangle pacdt) {
        for (Rectangle wall : walls.walls) {
            if (wall.intersects(pacdt.getX(), pacdt.getY(), pacdt.getWidth(), pacdt.getHeight())) {
                return false;
            }
        }
        return true;
    }

}
