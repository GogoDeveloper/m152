package sample;

import javafx.scene.shape.Rectangle;

import java.util.ArrayList;

public class WallsModel {
    public ArrayList<Rectangle> walls = new ArrayList<>();

    public WallsModel() {
        //Maze-Borders
        walls.add(new Rectangle(13, 916, 868, 1));
        walls.add(new Rectangle(13, 13, 1, 898.5));
        walls.add(new Rectangle(13, 13, 868.5, 1));
        walls.add(new Rectangle(886, 13, 1, 898.5));


        walls.add(new Rectangle(445, 629, 11, 92));
        walls.add(new Rectangle(344, 608, 214, 11));
        walls.add(new Rectangle(256, 505, 11, 114));
        walls.add(new Rectangle(634, 505, 11, 114));
        walls.add(new Rectangle(532, 694, 114, 11));
        walls.add(new Rectangle(256, 694, 114, 11));
        walls.add(new Rectangle(445, 796, 11, 114));
        walls.add(new Rectangle(532, 796, 93, 48));
        walls.add(new Rectangle(277, 796, 93, 48));
        walls.add(new Rectangle(19, 796, 60, 11));
        walls.add(new Rectangle(823, 796, 60, 11));
        walls.add(new Rectangle(721, 694, 93, 11));
        walls.add(new Rectangle(721, 714, 11, 93));
        walls.add(new Rectangle(88, 694, 93, 11));
        walls.add(new Rectangle(169, 714, 11, 93));
        walls.add(new Rectangle(19, 505, 161, 114));
        walls.add(new Rectangle(721, 505, 161, 114));
        walls.add(new Rectangle(19, 316, 161, 114));
        walls.add(new Rectangle(721, 316, 161, 114));
        walls.add(new Rectangle(345, 406, 213, 125));
        walls.add(new Rectangle(256, 215, 11, 214));
        walls.add(new Rectangle(277, 316, 93, 11));
        walls.add(new Rectangle(532, 316, 93, 11));
        walls.add(new Rectangle(634, 215, 11, 214));
        walls.add(new Rectangle(344, 215, 214, 11));
        walls.add(new Rectangle(446, 232, 11, 94));


        //The Blocks in the upper part of the maze
        walls.add(new Rectangle(87, 214, 93, 12));
        walls.add(new Rectangle(720, 214, 93, 12));
        walls.add(new Rectangle(87, 88, 93, 51));
        walls.add(new Rectangle(255, 88, 114, 51));
        walls.add(new Rectangle(531, 88, 114, 51));
        walls.add(new Rectangle(721, 88, 93, 51));
        walls.add(new Rectangle(443, 18, 12, 120));

    }
}
