package sample;

import javafx.scene.image.Image;
import javafx.scene.shape.Rectangle;


import java.util.ArrayList;

public class PacDotsModel {
    ArrayList<Rectangle> pacdots = new ArrayList<>();


    public double pdx = 46;
    public double pdy = 38;

    public double getPdx() {
        return pdx;
    }

    public void setPdx(double pdx) {
        this.pdx = pdx;
    }

    public double getPdy() {
        return pdy;
    }

    public void setPdy(double pdy) {
        this.pdy = pdy;
    }
}
