package sample;


import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;

import java.util.Random;


public class BlinkyController {
    double blx = 355;
    double bly = 445;
    public void blinkycontrol(Canvas canvas, GraphicsContext gc, Image blinky){


        Random move = new Random();

            canvas.setOnKeyReleased(k->{
                if (k.getCode() == KeyCode.RIGHT){
                    gc.clearRect(blx, bly, blinky.getWidth(), blinky.getHeight());
                    gc.drawImage(blinky, blx, bly);

                    blx += 1;
                }else if (k.getCode() == KeyCode.LEFT){
                    gc.clearRect(blx, bly, blinky.getWidth(), blinky.getHeight());
                    gc.drawImage(blinky, blx, bly);

                    blx -= 1;
                }
            });






    }
}
