package sample;

import javafx.animation.Timeline;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.canvas.*;
import javafx.scene.shape.Rectangle;


import static sample.GameController.*;


public class PacManController {

    public boolean right = false;
    public boolean left = false;
    public boolean up = false;
    public boolean down = false;

    public boolean interswall(Image pm) {
        for (Rectangle rectangle : GameController.walls.walls
        ) {
            if (rectangle.intersects(pmx, pmy, pm.getWidth(), pm.getHeight())) {
                return true;
            }
        }
        return false;
    }

    public boolean eatdot(Image pm) {
        for (Rectangle pacdot : GameController.pacDotsModel.pacdots) {
            if (pacdot.intersects(pmx, pmy, pm.getWidth(), pm.getHeight())) {
                return true;
            }
        }
        return false;
    }

    public void pacman(Canvas canvas, GraphicsContext gc, Image pm) {
        ImageView iv = new ImageView(pm);

        canvas.setOnKeyPressed(e -> {



            if (e.getCode() == KeyCode.RIGHT) {
                if (interswall(pm)) {
                    pmx -= 10;
                    System.out.println("Inter");
                } else {


                    gc.clearRect(pmx, pmy, pm.getWidth() + 1, pm.getHeight() + 1);
                    gc.drawImage(pm, pmx, pmy);
                    pmx += 4;
                }


            } else if (e.getCode() == KeyCode.UP) {
                if (interswall(pm)) {
                    pmy += 10;
                    System.out.println("Inter");
                } else {
                    iv.setRotate(-90);
                    SnapshotParameters params = new SnapshotParameters();
                    params.setFill(Color.TRANSPARENT);
                    Image rotatedImage = iv.snapshot(params, null);

                    gc.clearRect(pmx, pmy, pm.getWidth() + 1, pm.getHeight() + 1);
                    gc.drawImage(rotatedImage, pmx, pmy);

                    pmy -= 4;
                }


            } else if (e.getCode() == KeyCode.LEFT) {

                if (interswall(pm)) {
                    pmx += 10;
                    System.out.println("Inter");
                } else {
                    gc.clearRect(pmx, pmy, pm.getWidth() + 1, pm.getHeight() + 1);
                    gc.drawImage(pm, pmx + 55, pmy, -pm.getWidth(), pm.getHeight());
                    pmx -= 4;
                }


            } else if (e.getCode() == KeyCode.DOWN) {


                if (interswall(pm)) {
                    pmy -= 10;
                    System.out.println("Inter");
                } else {
                    iv.setRotate(90);
                    SnapshotParameters params = new SnapshotParameters();
                    params.setFill(Color.TRANSPARENT);

                    Image rotatedImage = iv.snapshot(params, null);
                    gc.clearRect(pmx, pmy, pm.getWidth() + 1, pm.getHeight() + 1);
                    gc.drawImage(rotatedImage, pmx, pmy);
                    pmy += 4;
                }


            }
            /*System.out.println(pmx);
            System.out.println(pmy);*/
        });
        /*canvas.setOnKeyReleased(e->{
            if (e.getCode() == KeyCode.RIGHT){
                right = false;
            }
            else if (e.getCode() == KeyCode.UP){
                up = false;
            }
            else if (e.getCode() == KeyCode.LEFT){
                left = false;
            }
            else if (e.getCode() == KeyCode.DOWN){
                down = false;
            }
        });*/

        /*if (right){

        }
        if (up){

        }
        if (left){

        }
        if (down){

        }*/

    }
}
